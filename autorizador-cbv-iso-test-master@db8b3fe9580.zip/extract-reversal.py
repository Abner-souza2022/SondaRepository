import sys
import re

def main(file_path):
    with open(file_path, 'r') as fp:
        for line in fp:
            # Identificar desfazimento
            # 2022-09-16 04:51:59.113 INFO [nioEventLoopGroup-3-2] t.iso.server.codec.IsoTransactionDecoder 935da1fe-32bc-44e2-8c10-42a327c49434 REQUEST <- 0420FE3800010481800000000040000001001641807200020758250042000000000025000000000004600000000025000916075157435046075052091606489409927425SN237219109301016462259282529678 30600201307036af272be7-7ba9-4e12-a1b9-7e4321185bac30800327530900103100010312001D313001098602602000000004350460916075052023#102@184#103@0020871349
            m = re.search(r'^.*REQUEST \<\- (0420.*)', line)
            if m:
                reversal = m.group(1)
                print(f'python3 ./cbv-cli.py --op=dm "--message={reversal}" --host=p0lvap02s37.banestes.sfb')

if __name__ == '__main__':
    main(sys.argv[1])