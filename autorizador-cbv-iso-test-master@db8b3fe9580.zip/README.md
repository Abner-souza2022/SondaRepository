# AUTORIZADOR CBV CLI

Command Line Interface (CLI) para realização de testes do fluxo de transação utilizando a função débito do cartão Banescard VISA.

## O que preciso?

Você vai precisar do python 3.7 ou superior instalado na sua máquina, bem como conseguir acessar (via rede corporativa ou VPN) o servidor de desenvolvimento do autorizador CBV (h0lvap02s37.banestes.sfb).
Não é preciso logar no servidor, basta conseguir "alcança-lo" via rede.

## O que posso testar?

Você terá a possíbilidade de realizar testes de integração do fluxo interno de autorização de compra com cartão Banescard VISA.

```text
Autorizador ISO -> Autorizador API -> Gestão Cartão -> Sensibilização de Saldo
```

## Como testar?

### Echo test

Echo test é a mensagem utilizada para validar a comunicação entre um cliente e o autorizador. Esta transação não executa nenhuma ação no autorizador.

```bash
python3 cbv-cli.py --op=echo
```

### Compra débito

Você precisará do número de um cartão (PAN) Banescard VISA válido, associado a uma conta corrente ou poupança ativa e com saldo disponível.<br>

#### Compra nacional

```bash
python3 cbv-cli.py --op=compra --pan=<num_plastico> --valor=<valor_compra_reais>
```

#### Compra parcial

```bash
python3 cbv-cli.py --op=compra --pan=<num_plastico> --valor=<valor_compra_reais> --parcial
```

#### Compra internacional

```bash
python3 cbv-cli.py --op=compra --pan=<num_plastico> --valor=<valor_compra_reais> --valor-dolar=<valor_em_dolar> --valor-original=<valor_na_moeda_original>
```

*A compra internacional só será autorizada, caso a config `PERMITE_DEBITO_INTERNACIONAL` esteja ativa.<br>
*O autorizador não realiza nenhum tipo de câmbio, por isso é necessário informar o valor da transação nas moedas BRL, USD e na moeda original.

### OCT (Original Credit Transaction)

Transação de crédito com sensibilização online. Esta transação segue os mesmos parâmetros da transação de compra, com adição do parâmetro `nome-remetente`

```bash
python3 cbv-cli.py --op=oct --pan=<num_plastico> --valor=<valor_compra_reais> --nome-remetente=<nome_pessoal_q_esta_enviado_grana>
```

### Desfazimento

O desfazimento só será concluído para transações que já foram aprovadas e vc precisará fornecer algumas informações ref a transação original.

* PAN (bit 2)
* Valor (bit 4) - No caso de compras internacionais deve-se informar todos os valores, seguindos os mesmos parâmetros da compra
* UUID (gerado automaticamente pela CLI e informado no bit 126)
* NSU de origem (bit 11)
* Data e hora (bits 13 e 12)

De posse das informações acima, basta executar o comando:

```bash
python3 cbv-cli.py --op=desfazimento --pan=<num_plastico> --valor=<valor_compra_reais> --uuid=<UUID transacao original> --nsu-origem=<NSU da transacao original> --data-hora=<Data e hora da transacao original no formato MMddHHmmss>
```

### Cancelamento

O cancelamento e o desfazimento compartilham dos mesmos parâmetros de entrada.<br>
Adicionalmente o cancelamento conta o parâmetro `valor-substituicao`, que deve-se informado no caso de testes de cancelamento parcial.

Os valores da transação original devem ser fornecidos seguindo as mesmas regras do desfazimento.

```bash
python3 cbv-cli.py --op=cancelamento --pan=<num_plastico> --valor=<valor_compra_reais> --uuid=<UUID transacao original> --nsu-origem=<NSU da transacao original> --data-hora=<Data e hora da transacao original no formato MMddHHmmss>
```

### Direct message

Envio de uma mensagem para o autorizador sem nenhum tipo de tratamento

```bash
python3 cbv-cli.py --op=dm "--message=ISO_MESSAGE"
```

### Dump

Desmonta uma mensagem ISO

```bash
python3 cbv-cli.py --op=dump "--message=ISO_MESSAGE"
```

** Todos os parâmetros de valores, devem ser informados utilizando `ponto` como separador, ou omitido caso seja necessário.

** Para informar um host e porta diferentes do ambiente de dev, utilize os parâmetros `host` e `port`, respectivamente.
