import datetime
import random

from messages import IsoMessage

class SondaSaqueCreditoMessage(IsoMessage):

    def __init__(self):
        self.message_data = {
            't': '0600',
            '3': '013000',
            '7': datetime.datetime.now().strftime('%m%d%H%M%S'),
            '11': str(random.randrange(10000, 999999)).rjust(6, '0'),
            '12': datetime.datetime.now().strftime('%H%M%S'),
            '13': datetime.datetime.now().strftime('%m%d'),
            '32': '00000000011',
            '41': 'A1290F00',
            '127': '0',
        }

    def _get_message(self):
        return self.message_data

    def set_nsu(self, nsu):
        self.message_data['127'] = nsu

    def set_conn_id(self, conn_id):
        self.conn_id = conn_id
