import datetime

from messages import IsoMessage

class EchoMessage(IsoMessage):

    def __init__(self):
        self.message_data = {
            't': '0800',
            '7': datetime.datetime.now().strftime('%m%d%H%M%S'),
            '12': datetime.datetime.now().strftime('%H%M%S'),
            '13': datetime.datetime.now().strftime('%m%d')
        }

    def _get_message(self):
        return self.message_data
