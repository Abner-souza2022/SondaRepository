from messages.financial_message import FinancialMessage

class OctMessage(FinancialMessage):

    def __init__(self):
        super().__init__()
        self.message_data['3'] = '032800'

    def set_nome_remetente(self, nome):
        length = str(len(nome)).rjust(3, '0')
        self.message_data['110'] = f'105{length}{nome}'
