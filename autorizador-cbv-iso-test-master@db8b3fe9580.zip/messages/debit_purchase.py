import datetime
import random
import uuid

from decimal import Decimal
from messages.financial_message import FinancialMessage

class DebitPurchaseMessage(FinancialMessage):

    def __init__(self):
        super().__init__()
        self.message_data['48'] = '3110010'

    def set_is_partial_authorization(self):
        self.message_data['48'] = '3110011'