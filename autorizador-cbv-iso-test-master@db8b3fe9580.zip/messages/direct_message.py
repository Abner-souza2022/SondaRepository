from messages import IsoMessage

class DirectMessage(IsoMessage):

    def __init__(self):
        super().__init__()

    def _get_message(self):
        return None
