import datetime
import random
import uuid

from decimal import Decimal
from messages import IsoMessage

class ReversalMessage(IsoMessage):

    def __init__(self):
        self.message_data = {
            't': '0420',
            '7': datetime.datetime.now().strftime('%m%d%H%M%S'),
            '11': str(random.randrange(10000, 999999)).rjust(6, '0'),
            '12': datetime.datetime.now().strftime('%H%M%S'),
            '13': datetime.datetime.now().strftime('%m%d'),
            '32': '00000000011',
            '41': 'A1290F00',
            '49': '986',
            '57': '010',
            '61': '123456',
            '90': '0200nsu_origem__data_hora_a'.ljust(42, '0'),
            '126': str(uuid.uuid4()),
        }

    def _get_message(self):
        print(self.message_data)
        return self.message_data

    def set_op(self, op):
        self.message_data['3'] = '004000' if op == 'cancelamento' else '004200'

    def set_pan(self, pan):
        self.message_data['2'] = pan

    def set_original_amount(self, amount):
        self._set_amount_data('4', amount)

    def set_usd_amount(self, amount):
        self._set_amount_data('5', amount)

    def set_brl_amount(self, amount):
        self._set_amount_data('6', amount)
        if '4' not in self.message_data:
            self._set_amount_data('4', amount)
        if '5' not in self.message_data:
            self._set_amount_data('5', amount)

    def set_uuid(self, uuid):
        length = str(len(uuid)).rjust(3, '0')
        self.message_data['48'] = f'307{length}{uuid}'

    def set_nsu_origem(self, nsu_origem):
        bit90_original = self.message_data['90']
        self.message_data['90'] = bit90_original.replace('nsu_origem__', nsu_origem.rjust(12, '0'))

    def set_data_hora(self, data_hora):
        bit90_original = self.message_data['90']
        self.message_data['90'] = bit90_original.replace('data_hora_', data_hora.rjust(10, '0'))

    def _set_amount_data(self, field, amount):
        if amount:
            self.message_data[field] = str((Decimal(amount) * 100).to_integral_value()).rjust(12, '0')
