import datetime
import random
import uuid

from decimal import Decimal
from messages import IsoMessage
# .putLllVar(110, "105005Spock")
class FinancialMessage(IsoMessage):

    def __init__(self):
        self.message_data = {
            't': '0200',
            '3': '002000',
            '7': datetime.datetime.now().strftime('%m%d%H%M%S'),
            '11': str(random.randrange(10000, 999999)).rjust(6, '0'),
            '12': datetime.datetime.now().strftime('%H%M%S'),
            '13': datetime.datetime.now().strftime('%m%d'),
            '22': '021',
            '32': '00000000011',
            '38': str(random.randint(1,999999)).rjust(6,'0'),
            '41': 'A1290F00',
            '42': '000000000122387',
            '43': 'MERCHANT NAME            CITY         BR',
            '49': '986',
            '52': '1234567890ABCDEF',
            '55': '1234567890ABCDEF',
            '57': '010',
            '61': '123456',
            '126': str(uuid.uuid4()),
        }

    def _get_message(self):
        return self.message_data

    def set_pan(self, pan):
        self.message_data['2'] = pan

    def set_original_amount(self, amount):
        self._set_amount_data('4', amount)

    def set_usd_amount(self, amount):
        self._set_amount_data('5', amount)

    def set_brl_amount(self, amount):
        self._set_amount_data('6', amount)
        if '4' not in self.message_data:
            self._set_amount_data('4', amount)
        if '5' not in self.message_data:
            self._set_amount_data('5', amount)

    def _set_amount_data(self, field, amount):
        if amount:
            self.message_data[field] = str((Decimal(amount) * 100).to_integral_value()).rjust(12, '0')
