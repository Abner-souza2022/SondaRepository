import struct
import socket
import time

import iso8583
import specs

from abc import ABC, abstractmethod

def current_time_millis():
    return round(time.time() * 1000)

class IsoMessage(ABC):

    @abstractmethod
    def _get_message(self):
        ...

    def send_message(self, connect_params):
        message = self._get_message()
        encoded_raw, encoded_dict = iso8583.encode(message, specs.conductor)

        print('REQUEST')
        iso8583.pp(encoded_dict, specs.conductor)
        print('------------------------------------------')

        self.send_raw_message(encoded_raw, connect_params)

    def send_raw_message(self, encoded_message, connect_params):
        conn = self._connect(connect_params)
        try:
            size_pack = struct.pack('!H', len(encoded_message))
            bin_iso = size_pack + encoded_message

            process_started_at = current_time_millis()

            bytes_sent = conn.send(bin_iso)
            if bytes_sent == -1:
                print('Não foi possível enviar a mensagem para o servidor')
                return
            size_bin = conn.recv(2)
            buffer_size = struct.unpack('!H', size_bin)[0]
            received = conn.recv(buffer_size)

            process_ended_at = current_time_millis()

            decoded_dic, encoded_dic_received = iso8583.decode(received, specs.conductor)

            print(f'RESPONSE ({(process_ended_at - process_started_at)}ms)')
            iso8583.pp(decoded_dic, specs.conductor)
        finally:
            conn.close()

    def _connect(self, connect_params):
        conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_address = self._get_server_address(connect_params)
        print(f'HOST.: {server_address[0]}')
        print(f'PORTA: {server_address[1]}')
        print('----------')
        conn.connect(server_address)
        return conn

    def _get_server_address(self, connect_params):
        if 'host' in connect_params and 'port' in connect_params:
            return (connect_params['host'], int(connect_params['port']))
        if 'host' in connect_params:
            return (connect_params['host'], 14300)
        return ('h0lvap02s37.banestes.sfb', 14300)
