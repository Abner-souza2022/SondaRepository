from commands import Command

from messages.oct import OctMessage

class OctCommand(Command):

    def execute(self, args):
        oct_message = OctMessage()
        self._apply_if_exists('pan', args, oct_message.set_pan, 'O PAN deve ser informado')
        self._apply_if_exists('valor-original', args, oct_message.set_original_amount)
        self._apply_if_exists('valor-dolar', args, oct_message.set_usd_amount)
        self._apply_if_exists('valor', args, oct_message.set_brl_amount, 'O valor da transacao deve ser informado')
        self._apply_if_exists('nome-remetente', args, oct_message.set_nome_remetente, 'O nome do remetente deve ser informado')
        if self.is_valid():
            oct_message.send_message(args)
