from commands import Command
from messages import direct_message

from messages.direct_message import DirectMessage

class DirectMessageCommand(Command):

    def execute(self, args):
        direct_message = DirectMessage()
        raw_message = args['message']
        direct_message.send_raw_message(bytes(raw_message, 'utf8'), args)
