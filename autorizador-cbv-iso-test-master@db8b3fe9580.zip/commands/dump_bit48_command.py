from commands import Command
from specs import bit48_tags

class DumpBit48Command(Command):

    def execute(self, args):
        message = args['message']
        print('DUMP BIT48 MESSAGE')
        self._decode(message)

    def _decode(self, message):
        TAG_LENGTH_FIELD = 3
        LENGTH_FIELD_LENGTH = 3
        i = 0
        while i < len(message):
            tag = message[i:i+TAG_LENGTH_FIELD]
            i += TAG_LENGTH_FIELD
            length = int(message[i:i+LENGTH_FIELD_LENGTH])
            i += LENGTH_FIELD_LENGTH
            value = message[i:i+length]
            i += length
            print(f'{tag}: {value} ({bit48_tags[tag]})')
