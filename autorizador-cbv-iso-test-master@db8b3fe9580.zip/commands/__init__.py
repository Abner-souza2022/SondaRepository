from abc import ABC, abstractmethod

class Command(ABC):

    def __init__(self):
        super().__init__()
        self._is_valid = True

    @abstractmethod
    def execute(self, args):
        ...

    def is_valid(self):
        return self._is_valid

    def _apply_if_exists(self, prop, args, func, message=None):
        if prop in args:
            if args[prop]:
                func(args[prop])
            else:
                func()
        elif message:
            self._is_valid = False
            print(message)