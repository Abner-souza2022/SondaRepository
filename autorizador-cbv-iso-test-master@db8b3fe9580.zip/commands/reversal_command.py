from commands import Command

from messages.reversal import ReversalMessage

class ReversalCommand(Command):

    def execute(self, args):
        reversal_message = ReversalMessage()
        reversal_message.set_op(args['op'])
        self._apply_if_exists('pan', args, reversal_message.set_pan, 'O PAN deve ser informado')
        self._apply_if_exists('valor-original', args, reversal_message.set_original_amount)
        self._apply_if_exists('valor-dolar', args, reversal_message.set_usd_amount)
        self._apply_if_exists('valor', args, reversal_message.set_brl_amount, 'O valor da transacao deve ser informado')
        self._apply_if_exists('uuid', args, reversal_message.set_uuid, 'O UUID da transacao original deve ser informado')
        self._apply_if_exists('nsu-origem', args, reversal_message.set_nsu_origem, 'O NSU da transacao original deve ser informado')
        self._apply_if_exists('data-hora', args, reversal_message.set_data_hora, 'A Data/Hora da transacao original deve ser informada')
        if self.is_valid():
            reversal_message.send_message(args)
