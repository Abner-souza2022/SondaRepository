from commands import Command

from messages.debit_purchase import DebitPurchaseMessage

class PurchaseCommand(Command):

    def execute(self, args):
        purchase_message = DebitPurchaseMessage()
        self._apply_if_exists('pan', args, purchase_message.set_pan, 'O PAN deve ser informado')
        self._apply_if_exists('valor-original', args, purchase_message.set_original_amount)
        self._apply_if_exists('valor-dolar', args, purchase_message.set_usd_amount)
        self._apply_if_exists('valor', args, purchase_message.set_brl_amount, 'O valor da transacao deve ser informado')
        self._apply_if_exists('parcial', args, purchase_message.set_is_partial_authorization)
        if self.is_valid():
            purchase_message.send_message(args)
