from commands import Command
import iso8583
import specs

from messages.sonda_saque_credito import SondaSaqueCreditoMessage

class SondaSaqueCommand(Command):

    def execute(self, args):
        sonda_message = SondaSaqueCreditoMessage()
        self._apply_if_exists('nsu', args, sonda_message.set_nsu, 'NSU deve ser informado')
        self._apply_if_exists('conn-id', args, sonda_message.set_conn_id, 'ID da conexao deve ser informado')
        if (self.is_valid()):
                message = sonda_message._get_message()
                encoded_raw, encoded_dict = iso8583.encode(message, specs.conductor)
                print('SONDA REQUEST')
                iso8583.pp(encoded_dict, specs.conductor)
                print('--------------')

                forward_message = {
                    't': '0302',
                    '105': encoded_raw.decode('utf8'),
                    '127': sonda_message.conn_id,
                }
                raw, dict = iso8583.encode(forward_message, specs.conductor)
                print('REQUEST')
                iso8583.pp(dict, specs.conductor)
                sonda_message.send_raw_message(raw, args)


