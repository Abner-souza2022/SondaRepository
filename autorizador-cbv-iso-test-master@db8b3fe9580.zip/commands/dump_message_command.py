import iso8583
import specs

from commands import Command

class DumpMessageCommand(Command):

    def execute(self, args):
        message = args['message']
        decoded_dic, encoded_dic_received = iso8583.decode(bytes(message, 'utf8'), specs.conductor)
        print(f'DUMP MESSAGE')
        iso8583.pp(decoded_dic, specs.conductor)
