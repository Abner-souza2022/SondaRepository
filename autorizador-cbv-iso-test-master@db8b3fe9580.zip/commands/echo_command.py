from commands import Command

from messages.echo_test import EchoMessage

class EchoCommand(Command):

    def execute(self, args):
        echo_message = EchoMessage()
        echo_message.send_message(args)