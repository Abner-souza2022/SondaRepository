import sys
import getopt

from commands.echo_command import EchoCommand
from commands.purchase_command import PurchaseCommand
from commands.reversal_command import ReversalCommand
from commands.oct_command import OctCommand
from commands.dm_command import DirectMessageCommand
from commands.dump_message_command import DumpMessageCommand
from commands.dump_bit48_command import DumpBit48Command
from commands.sonda_saque_command import SondaSaqueCommand

commands = {
    'echo': EchoCommand,
    'compra': PurchaseCommand,
    'desfazimento': ReversalCommand,
    'cancelamento': ReversalCommand,
    'oct': OctCommand,
    'dm': DirectMessageCommand,
    'dump': DumpMessageCommand,
    'dump-bit48': DumpBit48Command,
    'sonda-saque': SondaSaqueCommand
}

def norm_arg(arg_name):
    return arg_name.replace('--', '')

def main(args):
    args_list, _args = getopt.getopt(args, '', [
        'host=', 'port=', 'op=', 'pan=', 'valor=', 'valor-dolar=', 'valor-original=', 'uuid=', 'nsu-origem=',
        'data-hora=', 'valor-substituicao=', 'nome-remetente=', 'message=', 'parcial', 'nsu=', 'conn-id='
    ])
    args_map = {}
    for arg, value in args_list:
        args_map[norm_arg(arg)] = value
    if 'op' not in args_map:
        print('Informe a operacao a ser executada')
        return
    operation = args_map['op']
    if operation not in commands:
        print(f'Operacao {operation} nao suportada')
        return
    operation_command_class = commands[operation]
    operation_command = operation_command_class()
    operation_command.execute(args_map)

if __name__ == '__main__':
    main(sys.argv[1:])