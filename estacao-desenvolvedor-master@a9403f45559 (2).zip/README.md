# Script para instalação das ferramentas de desenvolvimento

O Script instala-ferramentas.bat efetua a intalação e configuração das ferramentas para desenvolvimento de aplicações JAVA, entre outras, no ambiente Windows.

Para usar basta executar o script instala-ferramentas.bat (Não é necessário ser administrador, porém é preciso estar conectado à rede SFB)

As seguintes ferramentas são instaladas:

| Ferramenta | Versão | Descrição |
| ---------- | ------ | --------- |
| Java JDK | 1.8.0_242 | Kit de Desenvolvimento Java, é um conjunto de utilitários que permitem criar sistemas de software para a plataforma Java. |
| Apache Maven | 3.6.3 | O Apache Maven é uma ferramenta de automação de compilação para Java. |
| JBoss Developer Studio | 12.0.0 GA | É uma versão customizada do Eclipse que engloba plug-ins e ferramentas que auxiliam no processo de desenvolvimento para plataformas da RedHat. |
| Git | 2.18.0 | Git é um sistema de controle de versões distribuído, usado principalmente no desenvolvimento de software. |
| Postman | 6.7.2 | Aplicação que permite enviar e receber dados via requisições HTTP. |
| Apache JMeter | 5.1.1 | JMeter é uma ferramenta utilizada para testes de carga em serviços oferecidos por sistemas computacionais. |
| OpenShift Client Tools | 3.11.117 | Interface em linha de comando para administração e monitoramento remoto do OpenShift. |
| Node.js | 12.21.0 | Node.js é um interpretador de código JavaScript com o código aberto. |
| Visual Studio Code | 1.30.2 | O Visual Studio Code é um editor de código-fonte |
| Jboss EAP | 7.2.4 | O JBoss Enterprise Application Platform é uma plataforma de tempo de execução de servidor de aplicativos baseada em assinatura e baseada em Java EE |